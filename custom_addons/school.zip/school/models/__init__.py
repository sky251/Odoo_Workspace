from . import school
from . import res_partner
from . import student
# from . import setttings
