Quotation Limit
------------------------------------

Odoo Version : Odoo 14.0 Community

Installation
-------------------------------------
Install the Application => Apps -> Quotation Limit

Project Task Timer Functionality
---------------------------------------------

With the help of above module we can limit the quotation between Credit and Blocking limits.
