{
    "name": "Sale Management",
    "version": "14.0.1.0.0",
    "category": "sale",
    "summary": "Sale management system",
    "sequence": 1,
    "website": "https://www.aktivesoftware.com/",
    "description": "",
    "depends": ["sale_management"],
    "data": [
        "views/sale_order_views.xml",
    ],
    "demo": [],
    "installable": True,
    "auto_install": False,
    "application": True,
}
