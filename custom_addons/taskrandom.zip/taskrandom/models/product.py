import random
import string
from odoo import api, fields, models
from odoo.tools.translate import _


class ProductTemplate(models.Model):
    _inherit = "product.template"

    rndm_str = fields.Char(string=_("Random String"))

    def random_string_generate(self):
        all_chars = list(string.ascii_letters)
        random.shuffle(all_chars)
        self.rndm_str = "".join(all_chars[:4]).upper()


class ProductProduct(models.Model):
    _inherit = "product.product"

    rndm_str = fields.Char(string=_("Random String"))

    def random_string_generate(self):
        all_chars = list(string.ascii_letters)
        random.shuffle(all_chars)
        self.rndm_str = "".join(all_chars[:4]).upper()

# N = 4
# res = ''.join(random.choices(string.ascii_uppercase + string.digits, k=N))
# print("\n\n\n\n\n\n The generated random string : " + res + "\n\n\n\n")
# self.rndm_str = res
