{
    "name": "Random String",
    "version": "14.0.1.0.0",
    "category": "Random",
    "summary": "Random String management system",
    "sequence": 1,
    "website": "https://www.aktivesoftware.com/",
    "description": "Showing button in product and product variant,that generate randon string",
    "depends": [
        "sale", "purchase",
    ],
    "data": [
        "views/product_views.xml",
    ],
    "demo": [],
    "installable": True,
    "auto_install": False,
    "application": True,
}
