**Credit/blocking limits exceeds
------------------------------------

Odoo Version : Odoo 14.0 Community

Installation
-------------------------------------
Install the Application => go to Apps -> search "Credit Blocking Limit"

Credit/blocking limits exceeds Functionality
---------------------------------------------

We can set credit/blocking limit for individual person,if the limit exceeds ,it will raise error and send mail.
It won't allow you to create new sales order if both limits is exceeds.
