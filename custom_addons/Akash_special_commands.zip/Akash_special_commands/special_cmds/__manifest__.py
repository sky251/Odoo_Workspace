{
    "name": "Special Commands",
    "version": "14.0.1.0.0",
    "category": "Eduction",
    "summary": "Special Commands on sale.order many2many",
    "sequence": 1,
    "website": "https://www.aktivesoftware.com/",
    "description": "commands",
    "depends": [
        "sale_management",
    ],
    "data": [
        "views/sale_order_inherit_views.xml",
    ],
    "demo": [],
    "installable": True,
    "auto_install": False,
    "application": True,
}
