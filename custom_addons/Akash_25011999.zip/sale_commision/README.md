**Sale Order Commission
------------------------------------

Odoo Version : Odoo 14.0 Community

Installation
-------------------------------------
Install the Application => go to Apps -> search "Sale Order Commission"

Sale Order Commission Functionality
---------------------------------------------
we can see total count on smart button in profile ,and clicking on that we can see selected order line.
we can set commision value and give discount for all product selected.
