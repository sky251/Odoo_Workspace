from . import res_partner, sale_order
